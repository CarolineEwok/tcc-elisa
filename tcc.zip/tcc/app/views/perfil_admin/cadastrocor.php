<?php  require_once "indexperfil.php"?>
    <!-- /. NAV SIDE  -->
    <div id="page-wrapper" >
        <div id="page-inner" class="container">


            <div class="ui text container form-sobre-fotos" >
                <div class="ui text container centered aligned">
                    <h1><label style="margin-left: 190px;"><font color="black">Cadastro de Cor</font></label></h1>
                </div><br>
                <form class="ui form" action="http://localhost/tcc/app/controllers/produto_controller.php?acao=salvarCor" method="post">

                    <div class="field">
                        <label style="margin-left: 270px;"><font color="#363636">Nome da Cor</font></label>
                        <input type="text" name="cor" placeholder="Nome da cor">
                    </div>

                    <a href="#"onclick="return confirm('Nova cor cadastrada com sucesso!');">
                    <button class="ui button" type="submit" style="background-color: #0a256a; color: white; margin-left: 260px;" >Cadastrar</button>
                    </a>
                </form>

            </div>

            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>

<?php require_once "rodape.php"; ?>