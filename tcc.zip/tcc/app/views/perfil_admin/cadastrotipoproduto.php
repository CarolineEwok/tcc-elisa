<?php  require_once "indexperfil.php"?>
    <!-- /. NAV SIDE  -->
    <div id="page-wrapper" >
        <div id="page-inner" class="container">


            <div class="ui text container form-sobre-fotos" >
                <div class="ui text container centered aligned">
                    <h1><label style="margin-left: 120px;"><font color="black">Cadastro de Tipo de Produto</font></label></h1>
                </div><br>
                <form class="ui form" action="http://localhost/tcc/app/controllers/produto_controller.php?acao=salvarTipo" method="post">

                    <div class="field">
                        <label><font color="#363636">Nome do novo tipo de produto</font></label>
                        <input type="text" name="tipo" placeholder="Nome do tipo">
                    </div>
                    <a href="#"onclick="return confirm('Nova tipo de produto cadastrado com sucesso!');">

                    <button class="ui button" type="submit" style="background-color: #0a256a; color: white; margin-left: 260px;" >Cadastrar</button>
                        </a>
                </form>

            </div>

            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>

<?php require_once "rodape.php"; ?>