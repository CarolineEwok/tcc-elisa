<?php require_once "indexperfil.php"; ?>

    <div id="page-wrapper">
    <div id="page-inner" class="container" style="margin-top: 0px;">


    <!-----AQUI FUNCIONALIDADE DO BOTÃO---

            href="http://localhost/tcc/app/controllers/admin_controller.php?acao=excluir&id_usuario=<?= $_SESSION['id_user'];?>"onclick="return confirm('Tem certeza que deseja excluir sua conta?');">

            AQUI FUNCIONALIDADE DO BOTÃO------>

    <div style="width: 900px; margin-left: 900px;"></div>  <div>
        <h3 style="width: 400px;"> Desativar / Ativar </h3><label class="switch">
            <input type="checkbox" checked="">
            <span class="slider round"></span>
        </label></div>

    <!-- Page Content -->
    <div class="col-md-6 col-sm-4" style="margin-left: 250px; margin-top: 100px">
        <div class="panel panel-primary" >
            <div class="panel-heading">
                Informações do perfil
            </div>
            <div class="panel-footer">
                Nome:  <?= $vend->getNome(); ?>
            </div>
            <div class="panel-footer">
                Email: <?= $vend->getEmail(); ?>
            </div>
            <div class="panel-footer">
                Telefone:  <?= $vend->getTelefone(); ?>
            </div>
            <div class="panel-footer">
                CPF:  <?= $vend->cpf; ?>
            </div>

            <div class="panel-footer">
                Empresa onde trabalha: <?= $vend->cnpj; ?>
            </div>


            <div class="panel-footer">
                <a class="btn btn-primary" href="?acao=editar" style="margin-left: 170px;"><i class="fa fa-edit "></i> Editar</a></div>
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
<?php require_once "rodape.php"; ?>