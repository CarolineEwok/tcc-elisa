<?php
require_once '../database/Conexao.php';
require_once '../models/Tamanho.php';


class CrudTamanho
{


    private $conexao;
    public $tamanho;

    public function __construct(){
        $this->conexao = Conexao::getConexao();
    }


    public function insertNovoTamanho($tamanho){

        $sqlTamanho = "INSERT INTO  tamanho (tamanho) VALUE ('$tamanho->tamanho')";
        $this->conexao->exec($sqlTamanho);
        $idTamanho = $this->conexao->lastInsertId();
    }





}