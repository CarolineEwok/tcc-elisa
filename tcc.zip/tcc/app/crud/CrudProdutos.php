<?php
    require_once '../database/Conexao.php';
    require_once '../models/Produto.php';

class CrudProdutos{
        
    private $conexao;
    public $produto;
        
    public function __construct(){
        $this->conexao = Conexao::getConexao();
    }

    public function cadastrar(Produto $produto){
        $sql = "INSERT INTO produtos (nome, preco, referencia, estoque, estoque_min, descricao,  idTipoProduto, adm_responsavel) 
                    VALUES ('{$produto->nome}', '{$produto->preco}', {$produto->referencia}, {$produto->estoque}, {$produto->estoqueMin}, 
                    '{$produto->descricao}', {$produto->tipoProduto}, {$produto->adm_responsavel})";

        $this->conexao->exec($sql);
        $id = $this->conexao->lastInsertId();



        //imagem
        $sqlImg = "INSERT INTO  imagem (imagem) VALUE ('$produto->imagem')";
        $this->conexao->exec($sqlImg);
        $idImagem = $this->conexao->lastInsertId();

        //prod_tamanho
        $pt = "insert into prod_tamanho (tam_id_tam, prod_id_prod) values ({$produto->tamanho}, {$id})";
        @$this->conexao->exec($pt);

        //prod_imagem
        $pi = "insert into prod_imagem (img_id_img, prod_id_prod) values ({$idImagem}, {$id})";
        @$this->conexao->exec($pi);

        //prod_cor
        $pc = "insert into prod_cor (cor_id_cor, prod_id_prod) values ({$produto->cor}, {$id})";
        @$this->conexao->exec($pc);
    }


    //public function getTiposProduto(){ falar com heitor que deu erro na hora de cadastrar
            //$res = $this->conexao->query("select tipo from tipo_produto order by tipo");
            //$tipos = $res->fetchAll(PDO::FETCH_ASSOC);
            //return $tipos;
    //}

    public function getTiposProduto(){
        $res = $this->conexao->query("select * from tipo_produto order by tipo");
        $tipos = $res->fetchAll(PDO::FETCH_ASSOC);
        return $tipos;
    }



    // public function getTamanhos(){ falar com heitor que deu erro no cadastrar
       //     $res = $this->conexao->query("select tamanho from tamanho order by tamanho");
         //   $tamanhos = $res->fetchAll(PDO::FETCH_ASSOC);
          //  return $tamanhos;
    //}
    public function getTamanhos(){
        $res = $this->conexao->query("select * from tamanho order by tamanho");
        $tamanhos = $res->fetchAll(PDO::FETCH_ASSOC);
        return $tamanhos;
    }


    public function getCores(){
            $res = $this->conexao->query("select * from cor order by cor");
            $cores = $res->fetchAll(PDO::FETCH_ASSOC);
            return $cores;
    }

    //AGRUPAMENTO DE PRODUTOS
    public function getTamanhoByReferencia($referencia){
        $res = $this->conexao->query("select idProdutos from produtos WHERE referencia = {$referencia}");
        $ids = $res->fetchAll(PDO::FETCH_ASSOC);

        //ok

        //----------------------------------------------------pegar ids dos tamanhos
        $ids = array_column($ids, 'idProdutos');
        $ids_string = implode(',', $ids);

        $consulta = "select DISTINCT tam_id_tam from prod_tamanho WHERE prod_id_prod IN($ids_string)";

        $res = $this->conexao->query($consulta);
        $ids_tamanhos = $res->fetchAll(PDO::FETCH_ASSOC);

        //----------------------------------------------------pagar os tamanhos
        $ids_tamanhos = array_column($ids_tamanhos, 'tam_id_tam');
        $ids_tamanhos_string = implode(',', $ids_tamanhos);

        $consulta = "select DISTINCT tamanho from tamanho WHERE idTamanho IN($ids_tamanhos_string)";

        $res = $this->conexao->query($consulta);
        $tamanhos = $res->fetchAll(PDO::FETCH_ASSOC);

        $tamanhos = array_column($tamanhos, 'tamanho');


        return $tamanhos;

    }


    public function getCoresByReferencia($referencia){
        //$res = $this->conexao->query("select * from cor order by cor");
        //$cores = $res->fetchAll(PDO::FETCH_ASSOC);
        return $cores = ['azul', 'verde', 'vermelho'];
    }

public function produto($cnpj){
        $w = $this->conexao->query("SELECT idProdutos FROM produtos where adm_responsavel = $cnpj");
    $z = $w->fetchAll(PDO::FETCH_ASSOC);

    $conta = count($z);

    return $conta;
}

    public function getProdutos($cnpj){

            $consulta = $this->conexao->query("SELECT * FROM produtos where adm_responsavel = $cnpj");
            $arrayProdutos = $consulta->fetchAll(PDO::FETCH_ASSOC);

            //print_r($arrayProdutos);

            return $arrayProdutos;
    }

    public function getImagens(){
            $consulta = $this->conexao->query("SELECT imagem FROM imagem");
            $imagens = $consulta->fetchAll(PDO::FETCH_ASSOC);

            return $imagens;
    }

    public function getProduto($id){
        $consulta = $this->conexao->query("SELECT * FROM produtos WHERE idProdutos = {$id}");
        $produto = $consulta->fetch(PDO::FETCH_ASSOC);

        //imagem
        $sql_img = "SELECT img_id_img FROM prod_imagem where prod_id_prod = {$id}";
        $id_img = $this->conexao->query($sql_img)->fetch(PDO::FETCH_ASSOC);

        if($id_img != false){
            $imagem1 = "SELECT imagem FROM imagem where id_imagem = {$id_img['img_id_img']}";
            $imagem = $this->conexao->query($imagem1)->fetch(PDO::FETCH_ASSOC);

            $imagem = $imagem['imagem'];

        }else{
            $imagem = "sem_foto.png";
        }

        //cor
        $sql_cor = "SELECT cor_id_cor FROM prod_cor where prod_id_prod = {$id}";
        $id_cor = $this->conexao->query($sql_cor)->fetch();

        if($id_cor != false){
            $cor1 = "SELECT cor FROM cor where id_cor = {$id_cor['cor_id_cor']}";
            $cor = $this->conexao->query($cor1)->fetch();

            $cor = $cor['cor'];

        }else {
            $cor = "sem cor";
        }

        //tipo_produto
        $sql_tipo = "SELECT tipo FROM tipo_produto where idTipoProduto = {$produto['idTipoProduto']}";
        $tipo_produto = $this->conexao->query($sql_tipo)->fetch();

        //tamanho
        $sql_tam = "SELECT tam_id_tam FROM prod_tamanho where prod_id_prod = {$produto['idProdutos']}";
        $id_tam = $this->conexao->query($sql_tam)->fetch();

        if($id_tam != false){
            $tamanho1 = "SELECT tamanho FROM tamanho where idTamanho = {$id_tam['tam_id_tam']}";
            $tamanho = $this->conexao->query($tamanho1)->fetch();

            $tamanho = $tamanho['tamanho'];

        }else {
            $tamanho = "sem tamanho";
        }

        return new Produto($produto['nome'], $produto['preco'], $produto['referencia'], $produto['estoque'], $produto['estoque_min'],
            $produto['descricao'],$tamanho, $cor, $tipo_produto['tipo'], $imagem, $produto['idProdutos'] );
    }

        public function editar($produto){
            $this->conexao->exec("UPDATE produtos SET nome = '{$produto->nome}',                                                             
                                                                preco = {$produto->preco},
                                                                referencia = {$produto->referencia},
                                                                estoque = {$produto->estoque},
                                                                estoque_min =  {$produto->estoqueMin}, 
                                                                descricao = '{$produto->descricao}'
            WHERE idProdutos = {$produto->id}");
        }





    }






//$prod = new Produto("teste domingo", 200, 344, 100, "bla", "","vermelha", "casaco","", "","" );

//$crud = new CrudProdutos();
//$crud->getTamanhoByReferencia(23232);

//$crud->cadastrar($prod); //funcionando

//$crud->getProduto(47); //funcionando

//$crud->getProdutos();  //funcionando