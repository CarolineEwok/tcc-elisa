<?php

require_once '../database/Conexao.php';
require_once '../models/Cor.php';

class CrudCor
{

    private $conexao;
    public $cor;

    public function __construct(){
        $this->conexao = Conexao::getConexao();
    }


    public function insertNovaCor($cor){

        $sqlCor = "INSERT INTO  cor (cor) VALUE ('$cor->cor')";
        $this->conexao->exec($sqlCor);
        $idCor = $this->conexao->lastInsertId();
    }



}