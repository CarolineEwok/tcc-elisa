<?php

    require_once "Usuario.php";
class Vendedor extends Usuario {
    public $cpf;
    public $cnpj;
    public $idVendedor;

    public function __construct($nome, $email, $senha, $telefone, $cpf, $cnpj , $idUsuario = null, $idVendedor = null){
        parent::__construct($nome, $email, $senha, $telefone, $idUsuario);

        $this->cpf = $cpf;
        $this->cnpj = $cnpj;
        $this->idVendedor = $idVendedor;
    }
}
